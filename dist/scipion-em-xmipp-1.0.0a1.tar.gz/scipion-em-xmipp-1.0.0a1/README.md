# scipion-em-xmipp

Plugin to use Xmipp programs within the Scipion framework.

You can install it either using the Scipion software following 
[this](https://github.com/I2PC/scipion/wiki/Integrated-Packages) (production users) 
or cloning it on your own and link it to Scipion following 
[this](https://github.com/I2PC/xmipp/wiki/Migrating-branches-from-nonPluginized-Scipion-to-the-new-Scipion-Xmipp-structure#xmipp-plugin) (developers). 
However, for **developers is strongly recommended** to follow [this](https://github.com/I2PC/xmipp#xmipp).
